% Demonstration of generalized cross validation procedure
% for NNR-GRRLF. 
%
% WARNING: IT IS VERY TIME CONSUMING, MAY TAKE HOURS TO 
% COMPLETE!
% 
% Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]

addpath NNR-GRRLF

% Load the data
load Figure1_data X Y H Nvox n ZB Xpos t
Y = reshape(Y,[Nvox,n])';
ZB = reshape(ZB,[Nvox,n])';

% Cross-validation fold
ncv = 5;

% Parallel optimization on a cluster
% SGE_TASK_ID = str2num(getenv('SGE_TASK_ID') );

% Parameter set, use the smaller set to speedup
cant = 2.^(0:15)';
% cant = 2.^(2:12)';
% cant = 2.^(2:5)';
nt = numel(cant);

t1 = 10;
t2 = 10;

OPTS0 = struct('t1', t1, ...
    't2', t2, ...
    'maxitr', 3e3, ...
    'reltol', 1e-5, ...
    'maxstep', 1e0, ...
    'plot', false);
OPTS = OPTS0;

NY = norm(Y,'fro');
AERR_ALL = nan(nt,nt,ncv);
NNB = nan(nt,nt,ncv);
NNL = nan(nt,nt,ncv);

AERR_CV_ALL = nan(nt,nt,ncv);
RERR_CV = nan(nt);
RERR = nan(nt);

ZB_CELL = cell(nt);
ZL_CELL = cell(nt);

blksize = ceil(n/ncv);
idxst = 1:blksize:n;
idxed = blksize:blksize:n+1;


% matfile = ['res_',num2str(SGE_TASK_ID)];
matfile = 'result';

tid = tic;

for kk=1:ncv
    
    % Cluster version
%     if kk~=SGE_TASK_ID
%         continue;
%     end
    
    tIdx = idxst(kk):idxed(kk);
    eIdx = setdiff(1:n,tIdx);

    tn = numel(tIdx);

    Ye = Y(eIdx,:);
    Xe = X(eIdx,:);
    Yt = Y(tIdx,:);
    Xt = X(tIdx,:);
    
    for ii=1:nt
        t1 = cant(ii);

        for jj=1:nt
            t2 = cant(jj);

            fprintf('(%d/%d,%d/%d) %d / %d ', ...
                ii,nt,jj,nt,(ii-1)*nt+jj,nt*nt);

        %     % No hot start
        %     OPTS0.t1 = t1;
        %     [B,L,E,OPTS] = naive_solver_v4(Y,X,H',OPTS0);

            % Hot start
            OPTS.t1 = t1;
            OPTS.t2 = t2;
            if jj==1 
                if ii>1 && ~isempty(ZB_CELL{ii-1,jj})
                    OPTS.ZB0 = ZB_CELL{ii-1,jj}; 
                    OPTS.ZL0 = ZL_CELL{ii-1,jj}; 
                end
            else
                OPTS.ZB0 = ZB_CELL{ii,jj-1};
                OPTS.ZL0 = ZL_CELL{ii,jj-1};
            end

            [B,L,E,OPTS] = NNR_GRRLF(Ye,Xe,H',OPTS);

            AERR_ALL(ii,jj,kk) = E^2;

            [Ub,Sb,Vb] = svd(B);
            [Ul,Sl,Vl] = svd(L);

            NNB(ii,jj,kk) = sum(abs(Sb(:)));
            NNL(ii,jj,kk) = sum(abs(Sl(:)));


            [COEF,SCORE,LATENT] = pca(L);
            ll = t;
            CL = (COEF(:,1:ll)'*H')';
            LSC = zeros(tn,ll);
            YE = Yt - Xt*B*H';
            for i=1:tn
                lsc = CL \ (YE(i,:)');
                LSC(i,:) = lsc;
            end
            AERR_CV_ALL(ii,jj,kk) = norm(YE-LSC*CL','fro')^2;

            ZB_CELL{ii,jj} = OPTS.ZB0;
            ZL_CELL{ii,jj} = OPTS.ZL0;

            rt = toc(tid);
            
    %         RERR_CV(ii,jj) = sqrt(sum(AERR_CV_ALL(ii,jj,:)))/NY;
    %         RERR(ii,jj) = sqrt(sum(AERR_ALL(ii,jj,:)))/NY;

            save(matfile,'AERR*','cant','rt');

            toc(tid);
        end

    end
            
end

rt = toc(tid);
save(matfile,'AERR*','cant','rt');

imagesc(sum(AERR_CV_ALL,3));