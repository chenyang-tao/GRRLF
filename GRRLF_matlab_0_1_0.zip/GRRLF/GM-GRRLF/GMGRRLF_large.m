function sol=GMGRRLF_large(Y,X,H,Nvox,n,d,t,opts)
% GMGRRLF_GCV_large  -   General manifold GRRLF solver
% implemented with Riemannian manifold optimation. 
% Y = X*B*C*H+W*LC*H+E
%
% Input: 
% Y         n x Nvox        Response variables for n subjects
% X         n x p           Predictors
% H         Nvox x Nknot    Smoothing matrix
% Nvox      1 x 1           Number of voxels (redundant...)
% n         1 x 1           Number of samples (redundant...)
% d         1 x 1           Effective dimension of covariate X
% t         1 x 1           Latent dimension
% opts      1 x 1           Parameters
% .COVFIRST 1 x 1           Estimate covariate effect first
% 
% Output:
% sol       1 x 1           
% .Bhat     p x d
% .Betahat  d x q           Betahat=Chat*H
% .What     n x t  
% .LBetahat t x q           LBetahat=LChat*H
% .AIC      1 x 1
% .BIC      1 x 1
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 



    d1 = d;
    t1 = t;
    
    VERBOSE = false;
    COVFIRST = true;
    
    if nargin==8
        if isfield(opts, 'VERBOSE')
            VERBOSE = opts.VERBOSE;
        end
        if isfield(opts, 'COVFIRST')
            COVFIRST = opts.COVFIRST;
        end
    end
    
    [~,p] = size(X);
    [~,Nknot] = size(H);
%     [n = size(Y);

    solver = @trustregions;
%     solver = @conjugategradient;
%     solver = @steepestdescent;

    % Whether use analytical Hessian or not
%     ANAL_HESS = false;
    ANAL_HESS = true;

    oblique.M = obliquefactory(n,t1);
    stiefel.M = stiefelfactory(p,d1);
    euclid_w.M = euclideanfactory(Nknot,t1);
    euclid_x.M = euclideanfactory(Nknot,d1);

    MAX_ITR = 50;
    thresCost = 1e-5;
    TR_OPTS.verbosity=0;
    warning('off', 'manopt:getHessian:approx');

    [Bhat,~] = qr(randn(p,d1),0);
    Zhat = X*Bhat;
    Chat = randn(Nknot,d1);
    Betahat = H*Chat;
    ZBhat = reshape((Zhat*Betahat')',[Nvox*n,1]);
    What = randn(n,t1);
    for s=1:t1, What(:,s) = What(:,s)/norm(What(:,s)); end
    LChat = randn(Nknot,t1);
    LBetahat = H*LChat;
    WLhat = reshape((What*LBetahat')',[Nvox*n,1]);
    R = Y - ZBhat - WLhat;
    cost_old = sum(R.^2);
    if VERBOSE, fprintf('%d:%.4f\n',0,cost_old); end

    Xn = reshape(repmat(X',[Nvox,1]),[p,Nvox*n])';
    HH = reshape(H,[1,Nvox*Nknot]);

    % Initialize the solution from least-square

    tic;

    % Voxelwise least square regression
    Yls = zeros(size(Y));
    for i=1:Nvox
        Idx = i:Nvox:n*Nvox;
        Yi = Y(Idx);
        bi = X \ Yi;
        Yls(Idx) = X*bi;
    end
    if VERBOSE, toc; end
    
    snr_ls = sum((Yls).^2)/sum(Y.^2);
    if VERBOSE, 
        fprintf('Estimated least-square SNR:%.4f\n', snr_ls);
    end

    % Thresholding strategy
%     if snr_ls>0.2
%         R = Y - Yls;
%     else
%         R = Y;
%     end
    
    if COVFIRST
        Yr = reshape(Y,[Nvox,n])';
        [Arr,Brr,Crr] = reducedRankRegression(Yr,X,d);
        Yrr = reshape((X*Crr')',[Nvox*n,1]);
        R = Y-Yrr;
        
%         R = Y - Yls;
    else
        R = Y;
    end

    
    if VERBOSE, fprintf('Init:%.4f\n',sum(R.^2)); end
    for itr=1:5
        oblique.cost = @(W)(sum((R-reshape( ...
            LBetahat*W',[Nvox*n,1])).^2));
        oblique.egrad = @(W)(-2*(LBetahat'*( ...
            reshape(R,[Nvox,n])-LBetahat*W'))');
        if ANAL_HESS
            oblique.ehess = @(W,U)(2*U*(LBetahat'*LBetahat));
        end
        if itr==1
            What = [];
            LChat = [];
        end
        [What, Wcost, info, options] = ...
            solver(oblique,What,TR_OPTS);
        euclid_w.cost = @(LC)(sum((R - reshape(H*LC*What', ...
            [Nvox*n,1])).^2));
        euclid_w.egrad = @(LC)(-2*H'*(reshape(R,[Nvox,n])- ...
            H*LC*What')*What);
        if ANAL_HESS
            euclid_w.ehess = @(LC,U)(2*(H'*H)*U*(What'*What));
        end

        Ht = repmat(H,[1,t1]);
        HtH = Ht'*Ht;
        HR = Ht'*reshape(R,[Nvox,n]);
        LD = zeros(Nknot*t1,Nknot*t1);
        RD = zeros(Nknot*t1,1);
        for i=1:n
            Wd = repmat(What(i,:),[Nknot,1]);
            Wd = diag(sparse(Wd(:)));
            LD = LD+Wd*HtH*Wd;
            RD = RD+Wd*HR(:,i);
        end
        LChat = reshape(LD\RD,[Nknot,t1]);
        
        
        LBetahat = H*LChat;
        WLhat = reshape((What*LBetahat')',[Nvox*n,1]);

        RR = R - WLhat;
        if VERBOSE, fprintf('Init-1:%.4f, ',sum(RR.^2)); toc; end
    %     fprintf('Init-1:%.4f\n',sum(RR.^2));
    end


    R = Y - WLhat;
    for itr=1:5
        stiefel.cost = @(B)(sum((R-reshape( ...
            Betahat*B'*X',[Nvox*n,1])).^2));
        stiefel.egrad = @(B)(-2*(Betahat'*(reshape( ...
            R,[Nvox,n])-Betahat*B'*X')*X)');
        if ANAL_HESS
            stiefel.ehess = @(B,U)(2*(X'*X)*U*(Betahat'*Betahat));
        end
        if itr==1
            Bhat = [];
            Chat = [];
        end
        [Bhat,Bcost,info,options] = ...
            solver(stiefel,Bhat,TR_OPTS);
        Zhat = X*Bhat;
        euclid_x.cost = @(C)(sum((R-reshape(H*C*Zhat',[Nvox*n,1])).^2));
        euclid_x.egrad = @(C)(-2*H'*(reshape(R,[Nvox,n])- ...
            H*C*Zhat')*Zhat);
        if ANAL_HESS
            euclid_x.ehess = @(C,U)(2*(H'*H)*U*(Zhat'*Zhat));
        end
        
        Hd = repmat(H,[1,d1]);
        HdH = Hd'*Hd;
        HR = Hd'*reshape(R,[Nvox,n]);
        D = zeros(Nknot*d1,Nknot*d1);
        RD = zeros(Nknot*d1,1);
        for i=1:n
            Wd = repmat(Zhat(i,:),[Nknot,1]);
            Wd = diag(sparse(Wd(:)));
            D = D+Wd*HdH*Wd;
            RD = RD+Wd*HR(:,i);
        end
        Chat = reshape(D\RD,[Nknot,d1]);

        Betahat = H*Chat;
        ZBhat = reshape((Zhat*Betahat')',[Nvox*n,1]);

        RR = R - ZBhat;
        if VERBOSE, fprintf('Init-2:%.4f, ',sum(RR.^2)); toc; end
    %     fprintf('Init-2:%.4f\n',sum(RR.^2));
    end


    for itr=1:MAX_ITR

        % Oblique manifold optimization
        R = Y - ZBhat;
        oblique.cost = @(W)(sum((R-reshape( ...
            LBetahat*W',[Nvox*n,1])).^2));
        oblique.egrad = @(W)(-2*(LBetahat'*( ...
            reshape(R,[Nvox,n])-LBetahat*W'))');
        if ANAL_HESS
            oblique.ehess = @(W,U)(2*U*(LBetahat'*LBetahat));
        end
        [What, Wcost, info, options] = ...
            solver(oblique,What,TR_OPTS);
        euclid_w.cost = @(LC)(sum((R - reshape(H*LC*What', ...
            [Nvox*n,1])).^2));
        euclid_w.egrad = @(LC)(-2*H'*(reshape(R,[Nvox,n])- ...
            H*LC*What')*What);
        if ANAL_HESS
            euclid_w.ehess = @(LC,U)(2*(H'*H)*U*(What'*What));
        end
        Ht = repmat(H,[1,t1]);
        HtH = Ht'*Ht;
        HR = Ht'*reshape(R,[Nvox,n]);
        LD = zeros(Nknot*t1,Nknot*t1);
        RD = zeros(Nknot*t1,1);
        for i=1:n
            Wd = repmat(What(i,:),[Nknot,1]);
            Wd = diag(sparse(Wd(:)));
            LD = LD+Wd*HtH*Wd;
            RD = RD+Wd*HR(:,i);
        end
        LChat = reshape(LD\RD,[Nknot,t1]);
        
        LBetahat = H*LChat;
        WLhat = reshape((What*LBetahat')',[Nvox*n,1]);

        % Stiefel manifold optimization
        R = Y - WLhat;
        stiefel.cost = @(B)(sum((R-reshape( ...
            Betahat*B'*X',[Nvox*n,1])).^2));
        stiefel.egrad = @(B)(-2*(Betahat'*(reshape( ...
            R,[Nvox,n])-Betahat*B'*X')*X)');
        if ANAL_HESS
            stiefel.ehess = @(B,U)(2*(X'*X)*U*(Betahat'*Betahat));
        end
        [Bhat,Bcost,info,options] = ...
            solver(stiefel,Bhat,TR_OPTS);
        Zhat = X*Bhat;
        euclid_x.cost = @(C)(sum((R-reshape(H*C*Zhat',[Nvox*n,1])).^2));
        euclid_x.egrad = @(C)(-2*H'*(reshape(R,[Nvox,n])- ...
            H*C*Zhat')*Zhat);
        if ANAL_HESS
            euclid_x.ehess = @(C,U)(2*(H'*H)*U*(Zhat'*Zhat));
        end
        Hd = repmat(H,[1,d1]);
        HdH = Hd'*Hd;
        HR = Hd'*reshape(R,[Nvox,n]);
        D = zeros(Nknot*d1,Nknot*d1);
        RD = zeros(Nknot*d1,1);
        for i=1:n
            Wd = repmat(Zhat(i,:),[Nknot,1]);
            Wd = diag(sparse(Wd(:)));
            D = D+Wd*HdH*Wd;
            RD = RD+Wd*HR(:,i);
        end
        Chat = reshape(D\RD,[Nknot,d1]);
        Betahat = H*Chat;
        ZBhat = reshape((Zhat*Betahat')',[Nvox*n,1]);

        R = Y-ZBhat-WLhat;
        cost = sum(R.^2);
        if VERBOSE, fprintf('%d:%.4f, ',itr,cost); toc; end
        if itr>0 && abs((cost_old-cost)/cost)<thresCost, break; end
        cost_old = cost;

    end

    % likelihood
    varR = var(R);
    logL = -n*Nvox*log(varR);
    % Y = ZB + WL
    % B:p x d1, C:Nknot x d1, W:Nknot x t1, L:n x t1
    k = p*d1+Nknot*d1+Nknot*t1+n*t1;
    AIC = k-logL;
    BIC = k*log(n*Nvox)-2*logL;
    % logL = -n*log(varR)-1/(2*varR)*sum(R.^2);
    
    sol = struct('AIC', AIC, 'BIC', BIC, ...
        'Bhat', Bhat, 'Betahat', Betahat, ...
        'What', What, 'LBetahat', LBetahat);


end