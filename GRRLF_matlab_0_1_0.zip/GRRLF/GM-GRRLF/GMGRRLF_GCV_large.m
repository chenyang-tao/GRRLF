function sol=GMGRRLF_GCV_large(Y,X,H,Nvox,n,d,t,opts)
% GMGRRLF_GCV_large  -   General manifold GRRLF solver
% implemented with Riemannian manifold optimation. 
% Estimation sequence determined by GCV.
% Y = X*B*C*H+W*LC*H+E
%
% Input: 
% Y         n x Nvox        Response variables for n subjects
% X         n x p           Predictors
% H         Nvox x Nknot    Smoothing matrix
% Nvox      1 x 1           Number of voxels (redundant...)
% n         1 x 1           Number of samples (redundant...)
% d         1 x 1           Effective dimension of covariate X
% t         1 x 1           Latent dimension
% opts      1 x 1           Parameters
% .ncv      1 x 1           Cross-validation fold
% 
% Output:
% sol       1 x 1           
% .Bhat     p x d
% .Betahat  d x q           Betahat=Chat*H
% .What     n x t  
% .LBetahat t x q           LBetahat=LChat*H
% .AIC      1 x 1
% .BIC      1 x 1
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

    ncv = 5;
    VERBOSE = true;

    if nargin==8
        if isfield(opts,'ncv')
            ncv = opts.ncv;
        end
        if isfield(opts,'VERBOSE')
            VERBOSE = opts.VERBOSE;
        end
    else
        opts = [];
    end

    blksize = ceil(n/ncv);
    idxst = 1:blksize:n;
    idxed = blksize:blksize:n+1;
    
    OPTS_CO.COVFIRST = true;
    OPTS_LT.COVFIRST = false;
    
    RES_co = nan(size(Y));
    RES_lt = nan(size(Y));
    
    for kk=1:ncv
        tIdx = idxst(kk):idxed(kk);
        eIdx = setdiff(1:n,tIdx);
        
        tn = numel(tIdx);
        ne = numel(eIdx);

        Ye = Y(eIdx,:);
        Xe = X(eIdx,:);
        Yt = Y(tIdx,:);
        Xt = X(tIdx,:);
        
        Ye = reshape(Ye',[Nvox*ne,1]);
        
        % Compute the generalization error with covariate first
        sol_co = GMGRRLF_large(Ye,Xe,H,Nvox,ne,d,t,OPTS_CO);
    
        % Compute the generalization error with latent first
        sol_lt = GMGRRLF_large(Ye,Xe,H,Nvox,ne,d,t,OPTS_LT);
        
        B_co = sol_co.Bhat; 
        B_lt = sol_lt.Bhat;
        
        Beta_co = sol_co.Betahat;
        Beta_lt = sol_lt.Betahat;
        
        Gamma_co = sol_co.LBetahat;
        Gamma_lt = sol_lt.LBetahat;
        
        R_co = Yt - Xt*B_co*Beta_co';
        R_lt = Yt - Xt*B_lt*Beta_lt';
        
        Lt_co = nan(tn,t);
        Lt_lt = nan(tn,t);
        
        for i=1:tn
            lt_co = Gamma_co \ (R_co(i,:)');
            lt_lt = Gamma_lt \ (R_lt(i,:)');
            Lt_co(i,:) = lt_co;
            Lt_lt(i,:) = lt_lt;
%             lsc = CL \ (YE(i,:)');
%             LSC(i,:) = lsc;
        end
        RES_co(tIdx,:) = R_co - Lt_co*Gamma_co';
        RES_lt(tIdx,:) = R_lt - Lt_lt*Gamma_lt';
    end
    
    if norm(RES_co)<norm(RES_lt)
        OPTS = OPTS_CO;
    else
        OPTS = OPTS_LT;
    end

%     if VERBOSE
%         fprintf('NRM_co=%.4e, NRM_lt=%.4e, CovFirst=%d\n', ...
%             norm(RES_co),norm(RES_lt),OPTS.COVFIRST);
%     end
    
    Y = reshape(Y',[Nvox*n,1]);
    sol = GMGRRLF_large(Y,X,H,Nvox,n,d,t,OPTS);
    
    params.sigx = -1; params.sigy = -1;
    pThres = 1e-2;
    
    if norm(RES_co)>norm(RES_lt)
        p = hsicTestGamma_pval(X,sol.What,params);
        if (p<pThres)
            OPTS = OPTS_CO;
            sol = GMGRRLF_large(Y,X,H,Nvox,n,d,t,OPTS);
        end
    end
    
    fprintf('NRM_co=%.4e, NRM_lt=%.4e, CovFirst=%d\n', ...
        norm(RES_co),norm(RES_lt),OPTS.COVFIRST);

end