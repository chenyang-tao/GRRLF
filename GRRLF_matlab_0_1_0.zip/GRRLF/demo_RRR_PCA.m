% Demonstration of RRR-PCA. Fixed estimation sequence. 
% If necessary, please modify the code to use GCV for 
% determining the optimal estimation sequence. 
% 
% Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]

addpath RRR-PCA-GRRLF
addpath utilities

p = 10;             % number of covariates
d = 2;              % number of effective dimensions
t = 2;              % number of latent factors

B = zeros(p,d);
B(1,1) = 1;
B(2,2) = 1;

std_e = 1;

n = 100;       % samples

bx0 = 0;
bx1 = 1;

Nvox = 1000;     % number of voxels in the field
Nknot = 50;     % number of knots
SGX = (bx1-bx0)/Nknot;

Xpos = linspace(bx0,bx1,Nvox)';
Xknot = linspace(bx0,bx1,Nknot)';

H = computeBspline(Xpos,Xknot,SGX);

C0 = randn(Nknot,d);
Beta0 = H*C0;           % Nvox x d

LC0 = randn(Nknot,t);
LBeta0 = H*LC0;

X = randn(n,p);
E = std_e*randn(Nvox*n,1);
Z = X*B;        % n x d
ZB = Z*Beta0';   % n x Nvox
ZB = reshape(ZB',[Nvox*n,1]);

W = randn(n,t);      % latent factors
WL = W*LBeta0';      % n x Nvox
WL = reshape(WL',[Nvox*n,1]);

Y = ZB + WL + E;
Y = reshape(Y,[Nvox,n])';

XC = X(:,1);
XX = X(:,2:end);

OPTS.VERBOSE = true;
% OPTS.VERBOSE = false;  % Turn off the output
[BX,BC,L] = RPR(Y,XX,XC,1,2,OPTS);

ZBhat = XX*BX+[ones(n,1),XC]*BC;

ZB = reshape(ZB,[Nvox,n])';

for i=[10]
    plot(Xpos,[ZB(i,:)',ZBhat(i,:)']);
end