function [A,B,C]=reducedRankRegression(Y,X,r,W)
% Reduced Rank Regression Y = X*C+E
% 
% Please remove the mean of X and Y before call this function!!!
% The mean will not be added back. 
%
% Input: 
% Y         n x q   Response variables for n subjects
% X         n x p   Predictors
% r         1 x 1   
% W         q x q   PSD weight matrix (not implemented)
% 
% If all covariates are fixed, leave X = []
% 
% Output:
% A         p x r   
% B         r x q
% C         p x q   C = A*B
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

    n = size(X,1);
    if nargin==3
        % W = I
        X = X - repmat(mean(X),[n,1]);
        Y = Y - repmat(mean(Y),[n,1]);
        Sxx = (X'/(n-1))*X;
        Sxy = (X'/(n-1))*Y;
%         Sxx = cov(X);
%         Sxy = xcov(X,Y,0,'unbiased');
        Si = Sxx\Sxy;
        S = Sxy'*Si;
        [V,D] = eigs(S,r);
        [~,sIdx] = sort(diag(D),'descend');
        V = V(:,sIdx);
        A = V;
        B = (Si*V)';
        C = A*B;
    else
        disp('Sorry, not implemented');
    end
end