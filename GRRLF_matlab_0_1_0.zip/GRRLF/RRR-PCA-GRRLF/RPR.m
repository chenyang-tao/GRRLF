function [BX,BC,L,SC]=RPR(Y,X,C,d,t,opts)
% RPR   -   RRR-PCA regression 
%           Y = X*BX+C*BC+L+E
%
% Estimate sequence: fixed covariate effect =>
% rank constrained effect => latent effect
% 
% Please remove the mean of X in practice.
%
% Input: 
% Y         n x q   Response variables for n subjects
% X         n x p   Predictors
% C         n x r   Fixed covariate
% d         1 x 1   Effective dimension of covariate X
% t         1 x 1   Latent dimension
% opts      1 x 1   
% .VERBOSE  1 x 1   Print residual norm
% 
% If all covariates are fixed, leave X = []
% 
% Output:
% BX        p x q   Rank-d covariate regression coefficient matrix
% BC        r x q   Fixed covariate regression coefficient matrix
% L         n x q   Rank-t latent response estimate
% SC        n x t   Latentn status estimate
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

    VERBOSE = false;
    
    if exist('opts','var')
        if isfield(opts,'VERBOSE')
            VERBOSE = opts.VERBOSE;
        end
    end

    MAX_ITR = 50;
    
    [n,q] = size(Y);
    [~,r] = size(C);
    [~,p] = size(X);
    
    % include the mean
    C = [ones(n,1) C];
    
    BC = zeros(r+1,q);
    BX = zeros(p,q);
    L = zeros(n,q);
    
    if p==0
        BX = zeros(1,q);
        X = zeros(n,1);
    end
    
    thres = 1e-5;
    
	tid=tic;
    for itr=1:MAX_ITR
        
        
        % Least square regression
        R = Y - X*BX - L;
        BC = C \ R;
        
        % Reduced rank regression
        if (p>0)
            R = Y - C*BC - L;
            [~,~,BX] = ...
                reducedRankRegression(R,X,d);
            BX = BX';
        end
        
        % Least square regression
        R = Y - X*BX - L;
        BC = C \ R;
        
        % PCA 
        if t>0
            R = Y - X*BX - C*BC;
            [COEF,SCORE] = pca(R);
            L = SCORE(:,1:t)*COEF(:,1:t)';
        end
        
        R = Y - X*BX - C*BC - L;
        e = sum(R(:).^2);
        if itr>1 && abs(e-e0)<thres, break; end
        e0 = e;
        if VERBOSE
            fprintf('%d,err=%e, ',itr,e);
            toc(tid);
        end
    end
    
    if nargout==4
        SC = SCORE(:,1:t);
    end

end