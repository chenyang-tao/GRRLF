% Demonstration of NNR-GRRLF estimation, using optimal
% parameter setting identified with GCV.
% 
% Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]

addpath NNR-GRRLF


load Figure1_data X Y H Nvox n ZB Xpos
Y = reshape(Y,[Nvox,n])';
ZB = reshape(ZB,[Nvox,n])';

t1 = 16;
t2 = 128;
% err_cv = 0.3744

OPTS0 = struct('t1', t1, ...
    't2', t2, ...
    'maxitr', 3e3, ...
    'reltol', 1e-5, ...
    'maxstep', 1e0, ...
    'plot', false);
OPTS = OPTS0;

[Bhat,Lhat,E,OPTS] = NNR_GRRLF(Y,X,H',OPTS);

ZBhat = X*Bhat*H';

zb1 = ZB(1,:);
zbhat1 = ZBhat(1,:);

plot(Xpos,[zb1',zbhat1']);
legend('Truth','Estimation');