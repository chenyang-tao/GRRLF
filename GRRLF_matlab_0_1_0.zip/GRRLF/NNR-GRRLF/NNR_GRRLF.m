function [B,L,E,OPTS]=NNR_GRRLF(Y,X,H,opts)
% NNR-GRRLF -   Nuclear norm regularization solver for GRRLF, 
%               implemented with Jaggi-Hazan algorithm. 
%
% Y = X*B*H+L*H+E
%
% Input: 
% Y         n x q   Response variables for n subjects
% X         n x p   Predictors
% H         m x q   Smoothing matrix
% opts      1 x 1   Parameters
% .t1       1 x 1   Nuclear norm constraint for \tilde{B}
% .t2       1 x 1   Nuclear norm constraint for \tilde{L}
% .MAXITR   1 x 1   Maximum number of iterations
% .MAXSTEP  1 x 1   Largest iteration step allowed
% .reltol   1 x 1   Stopping tolerance for the average relative 
%                   residual error improvement
% .ZB0      (p+m)x(p+m) Initial guess for ZB (hot start B)
% .ZL0      (n+m)x(n+m) Initial guess for ZL (hot start L)
% .SHOW_PLOT    1 x 1   Show residual convergence curve
% 
% Output:
% B         p x m   \tilde{B}
% L         n x m   \tilde{L}
% E         1 x 1   \| Y - X B H - L H \|_F
% OPTS      1 x 1   Current estimate ZB and ZL (for hot start)
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

t1 = 1;
t2 = 1;
MAXITR = 100;
SHOW_PLOT = true;
reltol = 1e-5;

[n,p] = size(X);
% q = size(Y,2);
m = size(H,1);

RANDOM_START = true;

if RANDOM_START
    v1 = randn(p+m,1);
    v2 = randn(n+m,1);
else
    v1 = ones(p+m,1);
    v2 = ones(n+m,1);
end

% Initialize ZB,ZL
v1 = v1/norm(v1);
ZB = v1*v1';
v2 = v2/norm(v2);
ZL = v2*v2';

if nargin==4
    if isfield(opts,'t1')
        t1 = opts.t1;
    end
    if isfield(opts,'t2')
        t2 = opts.t2;
    end
    if isfield(opts,'maxitr')
        MAXITR = opts.maxitr;
    end
    if isfield(opts,'plot')
        SHOW_PLOT = opts.plot;
    end
    if isfield(opts,'reltol')
        reltol = opts.reltol;
    end
    if isfield(opts,'ZB0')
        assert(isequal(size(opts.ZB0),[p+m,p+m]));
        ZB = opts.ZB0;
    end
    if isfield(opts,'ZL0')
        assert(isequal(size(opts.ZL0),[n+m,n+m]));
        ZL = opts.ZL0;
    end
    if isfield(opts,'maxstep')
        MAXSTEP = opts.maxstep;
    end
end

% transform the problem
% Y - X*t*(1/t)*B, since |B|_* \leq t
Xt = X*t1;

Bt = ZB(1:p,(p+1):end);
Lt = ZL(1:n,(n+1):end);

ZB1 = zeros(p);
ZB3 = zeros(m);
ZL1 = zeros(n);
ZL3 = zeros(m);

Et = nan(MAXITR,1);
EV = zeros(MAXITR,1);
EL = zeros(MAXITR,1);

HH = H*H';
YH = Y*H';
XYH = Xt'*YH;
XX = Xt'*Xt;

ak0 = 1e-4;

NY = norm(Y,'fro');

initTimer(MAXITR)
for k=1:MAXITR
    
    GB = 2*(XYH-(XX*Bt+t2*Xt'*Lt)*HH);
    GL = 2*t2*(YH-(Xt*Bt+t2*Lt)*HH);
    
    HB = [ZB1,GB;GB',ZB3];
    HL = [ZL1,GL;GL',ZL3];
    
    HB = HB + 1e-5*eye(p+m);
    HL = HL + 1e-5*eye(n+m);
    
    [vb,eb] = eigs(HB,1);
    [vl,el] = eigs(HL,1);

    EV(k) = vb'*HB*vb;
    EL(k) = vl'*HL*vl;
    
    OPT_LINE = true;
    
    if OPT_LINE
        
        % Optimal line search
        
        Db = (vb(1:p)*vb(p+1:end)'-Bt);
        Dl = (vl(1:n)*vl(n+1:end)'-Lt);
        Rk = Y - (Xt*Bt+t2*Lt)*H;
        Dk = (Xt*Db+t2*Dl)*H;
        RkH = Rk*H'; DkH = Dk*H';
        M1 = Xt'*RkH; M2 = t2*RkH; 
        N1 = Xt'*DkH; N2 = t2*DkH;
        
        ak = (M1(:)'*Db(:)+M2(:)'*Dl(:)) / ...
            (N1(:)'*Db(:)+N2(:)'*Dl(:));
        
        ak = sign(ak)*min(abs(ak),MAXSTEP);
        

        ZB = ZB+ak*(vb*vb'-ZB);
        ZL = ZL+ak*(vl*vl'-ZL);
        
        
        % Enforce PSD constraint
        if mod(k,100)==0 
%         if mod(k,10)==1
% || k==1
            [VB,EB] = eig(ZB);
            EB = diag(EB);
            EB(EB<0) = 0;
            EB = EB/sum(EB);
            EB = diag(EB);
            ZB = VB*EB*VB';
            ZB = (ZB+ZB')/2;
            [VL,EL] = eig(ZL);
            EL = diag(EL);
            EL(EL<0) = 0;
            EL = EL/sum(EL);
            EL = diag(EL);
            ZL = VL*EL*VL';
            ZL = (ZL+ZL')/2;
        end
        
        
        Bt = ZB(1:p,(p+1):end);
        Lt = ZL(1:n,(n+1):end);
    end

    if ~OPT_LINE
        % Line search
        ak = ak0;
        ZB0 = ZB+ak*(vb*vb'-ZB);
        ZL0 = ZL+ak*(vl*vl'-ZL);
        Bt = ZB0(1:p,(p+1):end);
        Lt = ZL0(1:n,(n+1):end);
        Et(k) = norm(Y-(Xt*Bt+t2*Lt)*H,'fro');
        et = Et(k);
        if k>1 && et>Et(k-1)
            while true
                ak = ak/2;
                ZB0 = ZB+ak*(vb*vb'-ZB);
                ZL0 = ZL+ak*(vl*vl'-ZL);
                Bt = ZB0(1:p,(p+1):end);
                Lt = ZL0(1:n,(n+1):end);
                et = norm(Y-(Xt*Bt+t2*Lt)*H,'fro');
                if et<Et(k-1) || ak<1e-6
                    Et(k) = et;
                    break;
                end
            end
        end
        while true
            ak = ak*2;
            ZB0 = ZB+ak*(vb*vb'-ZB);
            ZL0 = ZL+ak*(vl*vl'-ZL);
            Bt = ZB0(1:p,(p+1):end);
            Lt = ZL0(1:n,(n+1):end);
            et = norm(Y-(Xt*Bt+t2*Lt)*H,'fro');
            if et>Et(k)
                break;
            end
            Et(k) = et;
        end
        ak = ak/2;

        ZB = ZB+ak*(vb*vb'-ZB);
        ZL = ZL+ak*(vl*vl'-ZL);
        Bt = ZB(1:p,(p+1):end);
        Lt = ZL(1:n,(n+1):end);
    end
    
    Et(k) = norm(Y-(Xt*Bt+t2*Lt)*H,'fro');
    
    if k>10 && abs(mean(Et(k-(1:10)))-Et(k))/NY<reltol
        break;
    end
    
    coolTimer(k);
end
destroyTimer();

B = t1*Bt;
L = t2*Lt;
E = Et(k);

REt = Et/norm(Y,'fro');

if SHOW_PLOT
    plot(REt(1:k));
end

OPTS = opts;
OPTS.ZB0 = ZB;
OPTS.ZL0 = ZL;
OPTS.Et = Et;


function initTimer(numLoops)
% Input:
% numLoops : number of loops

% Copyright (c) Chenyang Tao, 2015. [cytao.fdu(AT)gmail.com]

    global timerTid
    global timerStr
    global totalLoops
    
    timerTid = tic;
    totalLoops = numLoops;
    
    timerStr = sprintf('Counting stated!\n');
    
    fprintf('%s',timerStr);

function coolTimer(doneLoops)
% Input:
% doneLoops : finished number of loops

% Copyright (c) Chenyang Tao, 2015. [cytao.fdu(AT)gmail.com]

    global timerTid
    global timerStr
    global totalLoops
    
    if isempty(timerTid)
        error(['Timer not initialized!!!' ...
            'Call initTimer(); before use']);
    end
    
    leftLoops = totalLoops-doneLoops;
    
    usedTime = toc(timerTid);
    
    projectTimeLeft = leftLoops*(usedTime/doneLoops);
    
    hhUsed = floor(usedTime/3600);
    usedTime = usedTime-hhUsed*3600;
    mmUsed = floor(usedTime/60);
    usedTime = usedTime-mmUsed*60;
    ssUsed = floor(usedTime);
    
    hhLeft = floor(projectTimeLeft/3600);
    projectTimeLeft = projectTimeLeft-hhLeft*3600;
    mmLeft = floor(projectTimeLeft/60);
    projectTimeLeft = projectTimeLeft-mmLeft*60;
    ssLeft = floor(projectTimeLeft);
    
    
    
    eraserStr = repmat('\b',[1,numel(timerStr)]);
    timerStr = sprintf(['Progress: %d/%d \t' ...
        '(time used:%d:%d:%d, ', ...
        'time left: %d:%d:%d)\n'], ...
        doneLoops,totalLoops, ...
        hhUsed,mmUsed,ssUsed, ...
        hhLeft,mmLeft,ssLeft);
    
    fprintf([eraserStr,timerStr]);

function destroyTimer()
% Copyright (c) Chenyang Tao, 2015. [cytao.fdu(AT)gmail.com]

    global timerTid
    global timerStr
    global totalLoops
    
    clear timerTid timerStr totalLoops