function Yls=voxLeastSquare(Y,X,n,Nvox)
% voxLeastSquare - Voxel-wise least squares regression
%
% Y = X*B+E
%
% Input: 
% Y         n x Nvox    Response variables for n subjects
% X         n x p       Predictors
% n         1 x 1       Number of samples (redundant...)
% Nvox      1 x 1       Number of voxels (redundant...)
% 
% 
% Output:
% Yls       n x Nvox    Yls = X*Bhat
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

    Yls = zeros(size(Y));
    for i=1:Nvox
        Idx = i:Nvox:n*Nvox;
        Yi = Y(Idx);
        bi = X \ Yi;
        Yls(Idx) = X*bi;
    end
end