function H=computeBspline(Xpos,Xcen,SGX)
% computeBspline - Gaussian RBF basis function 
% (Sorry about the misleading function name... )
%
% Input:
% Xpos      Nvox x d        Evaluation points (voxels)
% Xcen      Nknot x d       Knots
% SGX       1 x 1           Bandwidth parameter
%
% Output:
% H         Nvox x Nknot
% 
% Version: 0.1
% 
% Copyright (c) Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]
%
% REF:  Tao et al. (2016) Generalized reduced rank latent factor 
%       regression for high dimensional tensor fields, and 
%       neuroimaging-genetic applications. 

    Nknot = size(Xcen,1);
    N = size(Xpos,1);
    
    h = 2*SGX^2;
    
    H = zeros(N,Nknot);
    for i=1:Nknot
        H(:,i) = exp(-pdist2(Xpos,Xcen(i,:)).^2/h);
    end
end