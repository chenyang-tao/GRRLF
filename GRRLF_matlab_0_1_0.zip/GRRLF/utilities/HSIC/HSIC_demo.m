% Created by Chenyang Tao, 2015

N=100;

X=rand(N,1);
Y1=rand(N,1);
Y2=Y1+X;

params=struct('sigx', -1, 'sigy', -1);

P1=hsicTestGamma_pval(X,Y1,params);
P2=hsicTestGamma_pval(X,Y2,params);

fprintf('p1=%e,p2=%e\n', P1, P2);