% Comparison of GM-GRRLF, RRR and LSR under various latent
% influence strength.GCV is used to determine the optimal 
% sequence of estimation for GM-GRRLF. 
% 
% Chenyang Tao, 2016. [cytao.fdu(AT)gmail.com]

addpath utilities
addpath utilities/HSIC
addpath GM-GRRLF
importmanopt

p = 10;             % number of covariates
d = 2;              % number of effective dimensions
t = 2;              % number of latent factors

MLOOP = 10;         % number of runs

B = zeros(p,d);
B(1,1) = 1;
B(2,2) = 1;

std_e = 1;

n = 100;       % samples

bx0 = 0;
bx1 = 1;

Nvox = 100;     % number of voxels in the field
Nknot = 10;     % number of knots
SGX = 0.1;

Xpos = linspace(bx0,bx1,Nvox)';
Xknot = linspace(bx0,bx1,Nknot)';

H = computeBspline(Xpos,Xknot,SGX);

snr1_lst = [];
snr2_lst = [];
snr3_lst = [];
err_rr_lst = [];
err_rl_lst = [];
err_ls_lst = [];

disp('Estimation error (lower is better)');
disp('RUN, LS, RR, GRRLF');

tid=tic;
for mloop=1:MLOOP

    % plot(Xpos,H);

    C0 = randn(Nknot,d);
    Beta0 = H*C0;           % Nvox x d

    % Strength of latent effect
%     LC0 = 2*randn(Nknot,t); % Strong
    LC0 = 0.5*randn(Nknot,t); % Weak
%     LC0 = 0*randn(Nknot,t); % None
    LBeta0 = H*LC0;

    X = randn(n,p);

    E = std_e*randn(Nvox*n,1);
    Z = X*B;        % n x d
    ZB = Z*Beta0';   % n x Nvox
    ZB = reshape(ZB',[Nvox*n,1]);

    W = randn(n,t);      % latent factors
    WL = W*LBeta0';      % n x Nvox
    WL = reshape(WL',[Nvox*n,1]);

    Y = ZB + WL + E;

    % Reduced rank regression 
    Yr = reshape(Y,[Nvox,n])';
    [Arr,Brr,Crr] = reducedRankRegression(Yr,X,d);
    Yrr = reshape((X*Crr')',[Nvox*n,1]);
    % Rrr = Yr - X*Crr';

    % Voxelwise least square regression
    Yls=voxLeastSquare(Y,X,n,Nvox);

%     fprintf('True cost:%.4f\n', sum(E.^2));
    RRLF_OPTS.VERBOSE = true;
    RRLF_OPTS.VERBOSE = false;
    rl_sol = GMGRRLF_GCV_large(Yr,X,H,Nvox,n,d,t,RRLF_OPTS);
    Bhat = rl_sol.Bhat;
    Betahat = rl_sol.Betahat;
    ZBhat = reshape((X*Bhat*Betahat')',[Nvox*n,1]);
    What = rl_sol.What;
    LBetahat = rl_sol.LBetahat;
    WLhat = reshape((What*LBetahat')',[Nvox*n,1]);

    stat0 = sum((Y-Yrr).^2);
    stat1 = sum((Y-ZBhat-WLhat).^2);
    stat2 = sum((Y-Yls).^2);
    
    SNR1 = sum(ZB.^2)/sum(Y.^2);
    SNR2 = sum(WL.^2)/sum(Y.^2);
    SNR3 = sum(E.^2)/sum(Y.^2);
    
    err_rl = norm(ZB-ZBhat);
    err_ls = norm(ZB-Yls);
    err_rr = norm(ZB-Yrr);
    
    err_rr_lst = [err_rr_lst;err_rr];
    err_rl_lst = [err_rl_lst;err_rl];
    err_ls_lst = [err_ls_lst;err_ls];
    
    snr1_lst = [snr1_lst;SNR1];
    snr2_lst = [snr2_lst;SNR2];
    snr3_lst = [snr3_lst;SNR3];
    
    if (mod(mloop,10)==0), fprintf('%4d',mloop); end
    if (mod(mloop,100)==0), toc(tid); end
    

    % Average error
%     fprintf('%d, %.3e, %3e, %.3e ', ...
%         mloop,mean(err_ls_lst),mean(err_rr_lst), ...
%         mean(err_rl_lst));

    fprintf('%d, %.3e, %3e, %.3e ', ...
        mloop,err_ls_lst(mloop),err_rr_lst(mloop), ...
        err_rl_lst(mloop));
    toc(tid);
    
    
end
toc(tid);